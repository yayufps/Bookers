Rails.application.routes.draw do
 root 'homes#top'
 get 'top' => 'homes#top'
 get 'todolists/new'
 
 post 'todolists' => 'todolists#create'

 resources :books
 resources :lists
 
end
